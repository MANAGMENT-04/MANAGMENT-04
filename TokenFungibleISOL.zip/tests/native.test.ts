// tests/native.test.ts

import { Keypair, Connection } from "@solana/web3.js";
import { Token } from "@solana/spl-token";
import { expect } from "chai";
import { Program } from "@project-serum/anchor";
import { YourProjectName } from "../target/types/your_project_name";

describe("Token tests", () => {
    const connection = new Connection("https://api.testnet.solana.com", "confirmed");
    const payer = Keypair.generate();
    const programId = "YourProgramIdHere"; // Update with your actual program ID
    const program = new Program<YourProjectName>(programId, connection);

    it("Should mint tokens", async () => {
        const mint = await Token.createMint(connection, payer, payer.publicKey, null, 6, TOKEN_PROGRAM_ID);
        const recipient = payer.publicKey; // Use your wallet address
        await mint.mintTo(recipient, payer.publicKey, [], 10000 * Math.pow(10, 6));
        
        const balance = await mint.getAccountInfo(recipient);
        expect(balance.amount.toString()).to.equal((10000 * Math.pow(10, 6)).toString());
    });
});

