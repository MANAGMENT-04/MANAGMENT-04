import { Connection, PublicKey, Keypair } from '@solana/web3.js';
import { Program, Provider, web3 } from '@project-serum/anchor';
import { TOKEN_PROGRAM_ID } from '@solana/spl-token';

// Conectar al proveedor local
const provider = Provider.local(); 
const programId = new PublicKey("7jfGFCBnMNRDpDmiUz1bCVPevNtdVp9aEFmgALyRg9tq"); // Tu ID de programa
const program = new Program(idl, programId, provider); // Asegúrate de tener tu IDL

// Inicializar el token
async function initializeToken(decimals: number
    const user = provider.wallet.publicKey; // Dirección de la billetera del usuario
    const mint = Keypair.generate(); // Crear una nueva cuenta para el mint

    const tx = await program.rpc.initialize(new web3.BN(6), {
        accounts: {
            mint: mint.publicKey,
            user,
            systemProgram: web3.SystemProgram.programId,
        },
        signers: [mint],
    });

    console.log("Token initialized:", mint.publicKey.toString());
    return mint.publicKey;
}

// Mintar tokens
async function mintTokens(mintAddress: PublicKey, recipient: PublicKey, amount: number) {
    const tx = await program.rpc.mintTokens(new web3.BN(amount), {
        accounts: {
            mint: mintAddress,
            to: recipient,
            authority: provider.wallet.publicKey,
            tokenProgram: TOKEN_PROGRAM_ID,
        },
    });

    console.log("Tokens minted:", amount, "to", recipient.toString());
}

// Aquí puedes llamar a las funciones de inicialización y mint
// Por ejemplo:
// const mintAddress = await initializeToken(6); // Inicializa el token con 6 decimales
// await mintTokens(mintAddress, recipientPublicKey, 100); // Mint 100 tokens

